module.exports = {
  createTransport() {
    return {
      sendMail: () => {},
    };
  },
};
