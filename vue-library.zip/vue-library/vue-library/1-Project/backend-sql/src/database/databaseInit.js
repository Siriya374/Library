const init = async () => {
  return;
};

const middleware = async (req, res, next) => {
  return next();
};

exports.init = init;
exports.middleware = middleware;
