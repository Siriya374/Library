import routes from '@/modules/audit-log/audit-log-routes';
import store from '@/modules/audit-log/audit-log-store';

export default {
  routes,
  store,
};
