import routes from '@/modules/home/home-routes';

export default {
  routes,
};
