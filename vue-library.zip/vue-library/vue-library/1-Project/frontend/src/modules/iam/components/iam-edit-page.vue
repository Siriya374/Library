<template>
  <div>
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/' }">
        <app-i18n code="home.menu"></app-i18n>
      </el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: '/iam' }">
        <app-i18n code="iam.menu"></app-i18n>
      </el-breadcrumb-item>
      <el-breadcrumb-item>
        <app-i18n code="iam.edit.title"></app-i18n>
      </el-breadcrumb-item>
    </el-breadcrumb>

    <div class="app-content-page">
      <h1 class="app-content-title">
        <app-i18n code="iam.edit.title"></app-i18n>
      </h1>

      <div class="app-page-spinner" v-if="findLoading" v-loading="findLoading"></div>

      <el-form
        :label-position="labelPosition"
        :label-width="labelWidthForm"
        :model="model"
        :rules="rules"
        @submit.native.prevent="doSubmit"
        class="form"
        ref="form"
        v-if="model"
      >
        <el-form-item :label="fields.id.label" :prop="fields.id.name">
          <el-col :lg="11" :md="16" :sm="24">
            <el-input disabled v-model="model[fields.id.name]"/>
          </el-col>
        </el-form-item>

        <el-form-item :label="fields.email.label" :prop="fields.email.name">
          <el-col :lg="11" :md="16" :sm="24">
            <el-input disabled v-model="model[fields.email.name]"/>
          </el-col>
        </el-form-item>

        <el-form-item
          :label="fields.firstName.label"
          :prop="fields.firstName.name"
          :required="fields.firstName.required"
        >
          <el-col :lg="11" :md="16" :sm="24">
            <el-input v-model="model[fields.firstName.name]"/>
          </el-col>
        </el-form-item>

        <el-form-item
          :label="fields.lastName.label"
          :prop="fields.lastName.name"
          :required="fields.lastName.required"
        >
          <el-col :lg="11" :md="16" :sm="24">
            <el-input v-model="model[fields.lastName.name]"/>
          </el-col>
        </el-form-item>

        <el-form-item
          :label="fields.phoneNumber.label"
          :prop="fields.phoneNumber.name"
          :required="fields.phoneNumber.required"
        >
          <el-col :lg="11" :md="16" :sm="24">
            <el-input prefix-icon="el-icon-fa-plus" v-model="model[fields.phoneNumber.name]"/>
          </el-col>
        </el-form-item>

        <el-form-item
          :label="fields.avatarsIam.label"
          :prop="fields.avatarsIam.name"
          :required="fields.avatarsIam.required"
        >
          <el-col :lg="11" :md="16" :sm="24">
            <app-image-upload
              :max="fields.avatarsIam.max"
              :path="fields.avatarsIam.path"
              :schema="fields.avatarsIam.fileSchema"
              v-model="model[fields.avatarsIam.name]"
            ></app-image-upload>
          </el-col>
        </el-form-item>

        <el-form-item
          :label="fields.roles.label"
          :prop="fields.roles.name"
          :required="fields.roles.required"
        >
          <el-col :lg="11" :md="16" :sm="24">
            <el-select multiple placeholder v-model="model[fields.roles.name]">
              <el-option
                :key="option.value"
                :label="option.label"
                :value="option.value"
                v-for="option in fields.roles.options"
              ></el-option>
            </el-select>
          </el-col>
        </el-form-item>

        <el-form-item>
          <div class="form-buttons">
            <el-button
              :disabled="saveLoading"
              @click="doSubmit"
              icon="el-icon-fa-floppy-o"
              type="primary"
            >
              <app-i18n code="common.save"></app-i18n>
            </el-button>

            <el-button :disabled="saveLoading" @click="doReset" icon="el-icon-fa-undo">
              <app-i18n code="common.reset"></app-i18n>
            </el-button>
          </div>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';
import { FormSchema } from '@/shared/form/form-schema';
import { UserModel } from '@/modules/auth/user-model';
import { i18n } from '@/i18n';

const { fields } = UserModel;
const formSchema = new FormSchema([
  fields.id,
  fields.email,
  fields.firstName,
  fields.lastName,
  fields.phoneNumber,
  fields.avatarsIam,
  fields.roles,
]);

export default {
  name: 'app-iam-edit-page',

  props: ['id'],

  data() {
    return {
      rules: formSchema.rules(),
      model: null,
    };
  },

  computed: {
    ...mapGetters({
      labelPosition: 'layout/labelPosition',
      labelWidthForm: 'layout/labelWidthForm',
      record: 'iam/form/record',
      findLoading: 'iam/form/findLoading',
      saveLoading: 'iam/form/saveLoading',
    }),

    fields() {
      return fields;
    },
  },

  async created() {
    await this.doFind(this.id);
    this.model = formSchema.initialValues(this.record);
  },

  methods: {
    ...mapActions({
      doFind: 'iam/form/doFind',
      doUpdate: 'iam/form/doUpdate',
    }),

    doReset() {
      this.model = formSchema.initialValues(this.record);
    },

    async doSubmit() {
      try {
        await this.$refs.form.validate();
      } catch (error) {
        return;
      }

      const values = formSchema.cast(this.model);
      delete values.email;
      this.doUpdate(values);
    },

    i18n(code) {
      return i18n(code);
    },
  },
};
</script>
