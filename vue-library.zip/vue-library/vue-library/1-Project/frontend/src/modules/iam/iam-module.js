import routes from '@/modules/iam/iam-routes';
import store from '@/modules/iam/iam-store';

export default {
  routes,
  store,
};
