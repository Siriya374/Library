import routes from '@/modules/loan/loan-routes';
import store from '@/modules/loan/loan-store';

export default {
  routes,
  store,
};
