import StringField from '@/shared/fields/string-field';

export default class IdField extends StringField {}
