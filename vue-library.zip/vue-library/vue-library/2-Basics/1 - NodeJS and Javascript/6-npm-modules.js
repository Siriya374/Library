const moment = require("moment");

console.log(moment().format("YYYY-MM-DD"));
