module.exports = {
  database: {
    username: "postgres",
    dialect: "postgres",
    password: "",
    database: "todo",
    host: "localhost",
    logging: console.log
  }
};
